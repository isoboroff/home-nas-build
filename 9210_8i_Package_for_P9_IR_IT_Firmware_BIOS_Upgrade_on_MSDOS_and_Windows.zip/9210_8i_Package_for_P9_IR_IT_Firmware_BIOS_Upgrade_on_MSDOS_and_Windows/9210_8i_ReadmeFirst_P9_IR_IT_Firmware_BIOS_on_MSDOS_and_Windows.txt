************************************************************************************************************************
Package for P9 Firmware BIOS Upgrade on MSDOS & Windows
************************************************************************************************************************
LSI Host Bus Adapter(HBA) -LSI SAS 9210-8i 

Package Contents- 

Readme first note      :  9210_8i_ReadmeFirst_P9_IR_IT_Firmware_BIOS_on_MSDOS_and_Windows.txt 
Installer(SAS2FLSH)    :  \sas2flash_dos_rel\sas2flsh                   Version no:9.00.00.00     Release date:18-FEB-11 
Installer(SAS2FLASH)   :  \sas2flash_win_x86_rel\sas2flash              Version no:9.00.00.00     Release date:18-FEB-11 
Installer(SAS2FLASH)   :  \sas2flash_win_x64_rel\sas2flash              Version no:9.00.00.00     Release date:18-FEB-11 
Installer(SAS2FLASH)   :  \sas2flash_win_ia64_rel\sas2flash             Version no:9.00.00.00     Release date:18-FEB-11 
Installer(SAS2FLASH)
User Manual            :  SAS2Flash_User_manual_DB13_000179_00.pdf      Version no: NA            Release date: NA
Firmware               :  \firmware\HBA_9210_8i_IR\2108ir.bin           Version no:9.00.00.00     Release date:18-FEB-11
Firmware               :  \firmware\HBA_9210_8i_IT\2108it.bin           Version no:9.00.00.00     Release date:18-FEB-11
BIOS                   :  \sasbios_rel\mptsas2.rom                      Version no:7.17.00.00     Release date:18-FEB-11
Readme for BIOS        :  \sasbios_rel\mptbios.txt                      Version no: NA            Release date: NA
Release notes          :  SAS2BIOS_Release_notes_P9.txt, Firmware_Release_notes_P9.txt, SAS2FLASH_Release_notes_P9.txt 

------------------------------------------------------------------------------------------------------------------------ 
